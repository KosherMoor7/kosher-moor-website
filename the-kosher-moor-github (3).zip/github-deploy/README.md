# The Kosher Moor — Sovereign Marketplace

A full-stack sovereign e-commerce marketplace built as a single HTML file.

## 🌐 Live Site
[thekoshermoor.com](https://thekoshermoor.com)

## 📦 What's Inside
- **8 product categories** — unlimited product & service management via admin
- **7 payment methods** — Card, PayPal, Cash App, Venmo, Zelle, Apple Pay, Afterpay
- **AI Customer Service Agent** — powered by Claude (Sovereign)
- **Admin Dashboard** — products, services, CRM, email campaigns, reviews, tax & financials
- **2FA protected admin** — SHA-256 hashed credentials + TOTP
- **Full SEO** — meta, Open Graph, Twitter Cards, Schema.org JSON-LD

## 🚀 Deploy
This site is deployed via **GitHub Pages**.

1. Push changes to the `main` branch
2. GitHub Pages auto-deploys from root
3. Live at your custom domain within minutes

## 🔐 Admin Access
- **Shortcut:** `Ctrl + Shift + Alt + A` on the live site
- **Username:** `km_owner`
- **Password:** Set in `ADMIN_CREDS.passHash` (SHA-256 hash)
- **2FA:** Use backup code in `ADMIN_CREDS.totpBackupCode`

> ⚠️ Change the default password before going public. Generate a new SHA-256 hash at [sha256.online](https://sha256.online).

## 📁 Files
| File | Purpose |
|------|---------|
| `index.html` | Entire site — all code, styles, and logic |
| `_headers` | Security headers for Netlify deployments |
| `.nojekyll` | Disables Jekyll processing on GitHub Pages |
| `404.html` | Redirects unknown paths back to the site |
| `sitemap.xml` | Search engine sitemap |
| `robots.txt` | Search engine crawl instructions |

## ✅ Pre-Launch Checklist
- [ ] Change admin password (`ADMIN_CREDS.passHash` in index.html)
- [ ] Save your 2FA backup code somewhere safe
- [ ] Upload `og-image.jpg` (1200×630px) to your server
- [ ] Connect Mailchimp or Klaviyo in admin Email Campaigns tab
- [ ] Verify Cash App, Venmo, and Zelle payment handles
- [ ] Submit sitemap to [Google Search Console](https://search.google.com/search-console)
- [ ] Add your physical address to the AI system prompt (`KM_SYSTEM_PROMPT`)

## 📞 Contact
**Phone:** 469-928-9975  
**Email:** info@thekoshermoor.com

---
© 2026 The Kosher Moor. All Rights Reserved.
